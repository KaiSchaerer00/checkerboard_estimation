#' Nadaraya-Watson Kernel Smoother
#'
#' Performs kernel smoothing using the Nadaraya-Watson estimator via C code.
#'
#' @param x Vector of predictor values (x-coordinates).
#' @param y Vector of response values (y-coordinates).
#' @param xp Vector of points at which to evaluate the smoother.
#' @param kernel Integer indicating the kernel (1=Box, 2=Gaussian).
#' @param bandwidth The smoothing bandwidth.
#' @return A list with components 'x' (xp) and 'y' (the smoothed values).
#' @export
nw_e <- function(x, y, xp, kernel = 2L, bandwidth) {
  # Note: 
  # 1. We use the 'L' suffix to ensure 'kernel' is passed as an integer type
  # 2. The function called here must be registered in the NAMESPACE.
  
  result <- .Call("nw_e", x, y, xp, kernel, bandwidth,
                  PACKAGE = "nw") # The PACKAGE argument must match the package name
  
  return(result)
}